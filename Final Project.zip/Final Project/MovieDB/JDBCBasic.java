package edi.iupui.cit214;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCBasic {

	private static final String SELECT_FROM_CUSTOMER = "select * from customer";

	public static void main(String[] args) throws SQLException {

		Connection connection = null;
		try {
			loadDriver();
			connection = getConnection();
			//selectFromCustomerTable(connection);
			insertToCustomerTable(connection);

		} finally {
			connection.close();
		}

	}

	private static void selectFromCustomerTable(Connection connection) throws SQLException {

		PreparedStatement prepareStatement = connection.prepareStatement(SELECT_FROM_CUSTOMER);
		ResultSet resultSet = prepareStatement.executeQuery();

		System.out.println("========================================================================");
		System.out.println("CUSTOMER");
		System.out.println("========================================================================");

		while (resultSet.next()) {
			// , CUSTOMER_NAME, STREET, CITY, STATE, ZIP, BALANCE, CREDIT_LIMIT, REP_NUM
			String data = resultSet.getString("CUSTOMER_NUM") + ", " + resultSet.getString("CUSTOMER_NAME");
			System.out.println(data);
		}
		System.out.println("========================================================================");

	}

	private static void insertToCustomerTable(Connection connection) throws SQLException {

		PreparedStatement prepareStatement = connection.prepareStatement(" INSERT INTO CUSTOMER " +
				" VALUES " +
				" ('104','Cool Sports','2837 Greenway','Fillmore','FL','33336',6550.00,7500.00,'20') ");

		int result = prepareStatement.executeUpdate();

		if (result == 1) {
			System.out.println("Successfully inserted.");
		}
		else {
			System.out.println("Failed to insert.");
		}

	}

	private static Connection getConnection() {

		Connection connection = null;
		try {
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost/premiere?" + "user=root&password=mysql214");

			System.out.println("Database connection acquired");

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
		return connection;
	}

	private static void loadDriver() {
		try {

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			System.out.println("Driver Loaded");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
